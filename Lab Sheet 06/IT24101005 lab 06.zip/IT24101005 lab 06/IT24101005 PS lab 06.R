setwd("C:\\Users\\User\\Desktop\\IT24101005 lab 06")

#Question 1

#1
#Binomial Distribution

#2
1-pbinom(47,50,0.85,lower.tail =FALSE)


#Question 2

#1
#number of customer calls per hour

#2
#poisson Distribution

#3
dpois(15,12)
